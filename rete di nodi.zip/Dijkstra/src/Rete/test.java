package Rete;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Rete rete = new Rete();
			
			/*QUI MI PREPARO I NODI DA INSERIRE */
			Info inf1 = new Info("a",0);
			Info inf2 = new Info("b",0);
			Info inf3 = new Info("c",0);
			Info inf4 = new Info("d",0);
			Info inf5 = new Info("e",0);
			Info inf6 = new Info("f",0);
			Info inf7 = new Info("g",0);

			//INIZALIZZO LA RETE CON LA ROOT
			rete.addChild(rete.getPtr(),inf1);
			
			//AGGIUNGO B E C COME FIGLI "STANDARD" DI A
			rete.addLeft(rete.cercaNodo(rete.getPtr(),inf1),inf2);
			rete.addRight(rete.cercaNodo(rete.getPtr(),inf1),inf3);
			//ORA COLLEGO B E C, PASSANDO AD addRight(NodoRete n, NodoRete info) IL NODO B COME "PADRE" DI C
			rete.addRight(rete.cercaNodo(rete.getPtr(),inf2),rete.cercaNodo(rete.getPtr(),inf3));
			//AGGIUNGO D COME FIGLIO STANDARD DI B
			rete.addRight(rete.cercaNodo(rete.getPtr(),inf2),inf4);
			//AGGIUNGIUNGO D COME FIGLIO DI C, DANDO QUINDI A D DUE PADRI DIVERSI
			rete.addLeft(rete.cercaNodo(rete.getPtr(),inf3),rete.cercaNodo(rete.getPtr(),inf4));
			//CREO F COME FIGLIO STANDARD DI C
			rete.addRight(rete.cercaNodo(rete.getPtr(),inf3),inf5);
			//CREO DUE FIGLI STANDARD (E,G) PER F
			rete.addLeft(rete.cercaNodo(rete.getPtr(),inf5),inf6);
			rete.addRight(rete.cercaNodo(rete.getPtr(),inf5),inf7);
			//COLLEGO D COME "FIGLIO" DI E
			rete.addLeft(rete.cercaNodo(rete.getPtr(),inf5),rete.cercaNodo(rete.getPtr(),inf4));
			
			/* TA DAAA */ 
			
	}

}

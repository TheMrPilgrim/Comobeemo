/**
 * 
 */
package Rete;

/**
 * @author Danilo
 *
 */
/*	DISCLAIMER
 * Anche se � possibile impostare un nodo come il padre della root
 * farlo blocca il programma in un loop infinito se il nodo che stai cercando 
 * non esiste nella rete
*/
public class Rete {
	
	NodoRete ptr;		//nodo di origine MAI COLLEGARE COME FIGLIO
	
	public Rete() {ptr=null;}
	
	public NodoRete getPtr() {return this.ptr;}
	
	public void addChild (NodoRete n,Info info){			//copia della addFiglio del libro
		NodoRete n1 = new NodoRete(info);					//al momento serve solo per inserire il primo nodo
		
		if(ptr==null) {
			ptr=n1;
			return;
		}
		NodoRete p;
		p=cercaNodo(ptr,info);
		if(p!=null) {
			if(p.getLeft()!=null) {
				p.setLeft(n1);
				return;
			} p.setRight(n1);
		}
	}
	
	public void addLeft(NodoRete n,Info info) {				//aggiunge un nodo con info dopo il nodo ricevuto	
		NodoRete n1 = new NodoRete(info);					//per ora va usata insieme alla cerca nodo per avere il nodo di inserimento
		if(n!=null) {n.setLeft(n1);return;}
		return;
	}
	public void addRight(NodoRete n,Info info) {			//come sopra ma aggiunge il nodo a destra
		NodoRete n1 = new NodoRete(info);
		if(n!=null) {n.setRight(n1);return;}
		return;
	}
	public void addLeft(NodoRete n, NodoRete info){			//permette di collegare due nodi (B;C) direttamente	
		if(n!=null) {n.setLeft(info);return;}				//da utilizzare con la cerca nodo per avere il nodo a cui inserire
		return;
	}
	public void addRight(NodoRete n,NodoRete info) {		//come sopra ma a destra
		if(n!=null) {n.setRight(info);return;}
		return;
	}
	public NodoRete cercaNodo(NodoRete p, Info key) {		//ritorna il nodo con la info inserita partendo dal nodo che viene inserito
		try{NodoRete p1=null;								//da utilizzare partendo dalla root
		if(p==null) {return null;}
		if (p.getInfo().equals(key)) {return p;}
		
		if (p.getLeft()!=null) {
			p1=cercaNodo(p.getLeft(),key);
			if (p1!=null) {return p1;}
		}
		if(p.getRight()!=null) {
			p1=cercaNodo(p1.getRight(),key);
			if (p1!=null) {return p1;}
		}
		return null;}catch(java.lang.NullPointerException e){return null;}
	}
	
}

package Rete;

public class NodoRete {
	Info info;					//info contiene nome e colore del nodo
	NodoRete left;				//figlio di sinistra
	NodoRete right;				//figlio di desta
	
	public NodoRete() {}
	
	public NodoRete(Info s) {
		this.info = s;
		this.left = null;
		this.right = null;	
	}
	public NodoRete(NodoRete n) {
		this.info=n.getInfo();
		this.left=n.getRight();
		this.right=n.getLeft();
	}
	public void setInfo(Info s) {this.info=s;}
	public void setLeft(NodoRete n) {this.left=n;}
	public void setRight(NodoRete n) {this.right=n;}
	
	public Info getInfo() {return this.info;}
	public NodoRete getLeft() {return this.left;}
	public NodoRete getRight() {return this.right;}

}

package Rete;
public class Info {
	String name;
	int color;
	
	public Info(String n, int c) {
		this.name=n;
		this.color=c;
	}
	public Info() {}
	public Info(Info i) {
		this.name=i.getName();
		this.color=i.getColor();	
	}
	
	public String getName(){return this.name;}
	public int getColor() {return this.color;}
	
	public void setName(String n) {this.name=n;}
	public void setColor(int c) {this.color=c;}
	
}
